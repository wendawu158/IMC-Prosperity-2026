from typing import Any

import jsonpickle

from dashboard_objects.variables import ask_prices
from datamodel import *


class Trader:

    def bid(self):
        pass

    def run(self, state: TradingState):
        """
        Overarching algorithm
        """

        # Capture to a variable
        self.state = state
        self.past_trader_data: Dict[Symbol, Dict[str, Any]] = {}

        if state.traderData != "":
            self.past_trader_data = jsonpickle.decode(self.state.traderData)

        # Output variables initialising
        self.orders: Dict[Symbol, List[Order]] = dict()
        self.future_trader_data: Dict[Symbol, Dict[str, Any]] = dict()

        # The trading logic
        self.ash_coated_osmium()

        return self.orders, 0, jsonpickle.encode(self.future_trader_data)

    # WIP
    def ash_coated_osmium(self):
        # Tomatoes
        TOMATOES = "ASH_COATED_OSMIUM"

        # Previous data
        past_data = self.past_trader_data.get(TOMATOES, {})

        # Useful information from the TradingState
        self.orders[TOMATOES] = list()
        bids_tomatoes = self.state.order_depths[TOMATOES].buy_orders
        asks_tomatoes = self.state.order_depths[TOMATOES].sell_orders

        # Previous best non-outlier bid and ask for tomatoes
        previous_best_stable_ask = past_data.get("previous best stable ask", -1)
        previous_best_stable_bid = past_data.get("previous best stable bid", -1)
        previous_best_stable_midpoint = (previous_best_stable_ask + previous_best_stable_bid) / 2

        # Taking immediately profitable trades
        for bid in bids_tomatoes.keys():
            if bid > previous_best_stable_midpoint:
                self.orders[TOMATOES].append(Order(TOMATOES,
                                                   bid,
                                                   -1 * bids_tomatoes[bid])
                                             )

        for ask in asks_tomatoes.keys():
            if ask < previous_best_stable_midpoint:
                self.orders[TOMATOES].append(Order(TOMATOES,
                                                   ask,
                                                   -1 * asks_tomatoes[ask])
                                             )

        """
        Different types of best (they may not necessarily be different values)
        Best represents the best on the orderbook
        Best fair represents the best on the orderbook that is profitable, when compared to the previous prices
        Best stable represents the true movement of the price, compared to previous stable prices, it should be either
        one unit up, one unit down, or no movement.
        """

        best_ask = sorted(self.state.order_depths[TOMATOES].sell_orders.keys())[0]
        best_bid = sorted(self.state.order_depths[TOMATOES].buy_orders.keys())[-1]

        best_stable_ask = best_ask
        best_stable_bid = best_bid

        if abs(best_stable_ask - previous_best_stable_ask) > 1:
            best_stable_ask = sorted(asks_tomatoes.keys())[1]
            if abs(best_stable_ask - previous_best_stable_ask) > 1:
                best_stable_ask = sorted(asks_tomatoes.keys())[2]
                if best_stable_ask > previous_best_stable_ask + 1:
                    best_stable_ask = previous_best_stable_ask + 1
                elif best_stable_ask < previous_best_stable_ask - 1:
                    best_stable_ask = previous_best_stable_ask - 1

        if abs(best_stable_bid - previous_best_stable_bid) > 1:
            best_stable_bid = sorted(bids_tomatoes.keys())[-2]
            if abs(best_stable_bid - previous_best_stable_bid) > 1:
                best_stable_bid = sorted(bids_tomatoes.keys())[-3]
                if best_stable_bid > previous_best_stable_bid + 1:
                    best_stable_bid = previous_best_stable_bid + 1
                elif best_stable_bid < previous_best_stable_bid - 1:
                    best_stable_bid = previous_best_stable_bid - 1

        self.future_trader_data[TOMATOES] = {"previous best stable ask": best_stable_ask,
                                             "previous best stable bid": best_stable_bid}

        # Market making
        best_fair_mm_ask = best_ask - 1
        best_fair_mm_bid = best_bid + 1

        for price in sorted(asks_tomatoes.keys()):
            if best_fair_mm_ask < previous_best_stable_midpoint:
                best_fair_mm_ask = price - 1
                break

        for price in sorted(bids_tomatoes.keys()):
            if best_fair_mm_bid > previous_best_stable_midpoint:
                best_fair_mm_bid = price + 1
                break

        self.orders[TOMATOES].append(
            Order(TOMATOES, best_fair_mm_bid, 40)
        )
        self.orders[TOMATOES].append(
            Order(TOMATOES, best_fair_mm_ask, -40)
        )

        # The number of tomatoes that we hold
        position_tomatoes = 0

        # How many tomatoes are we holding?
        try:
            position_tomatoes = self.state.position[TOMATOES]
        except KeyError:
            pass

        # Rebalance our inventory, if we are out of balance
        # This is to prevent us from getting into situations where we are unable to place profitable trades
        # Basically, we buy up any trades at the true price to rebalance our position
        if position_tomatoes > 20 and bids_tomatoes.get(previous_best_stable_midpoint, 0) > 0:
            self.orders[TOMATOES].append(
                Order(TOMATOES, previous_best_stable_midpoint,
                      -1 * bids_tomatoes.get(previous_best_stable_midpoint)
                      )  # We don't wanna over correct
            )

        elif position_tomatoes < 20 and asks_tomatoes.get(previous_best_stable_midpoint, 0) > 0:
            self.orders[TOMATOES].append(
                Order(TOMATOES, previous_best_stable_midpoint,
                      -1 * asks_tomatoes.get(previous_best_stable_midpoint)
                      )  # We don't wanna over correct
            )