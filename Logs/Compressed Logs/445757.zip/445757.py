from typing import Any
from datamodel import *


class Trader:

    def bid(self):
        pass

    def run(self, state: TradingState):
        """
        Overarching algorithm
        """

        # Capture to a variable
        self.state = state
        self.past_trader_data: Dict[Symbol, Dict[str, Any]] = {}

        if state.traderData != "":
            self.past_trader_data = jsonpickle.decode(self.state.traderData)

        # Output variables initialising
        self.orders: Dict[Symbol, List[Order]] = dict()
        self.future_trader_data: Dict[Symbol, Dict[str, Any]] = dict()

        # The trading logic
        self.hydrogel_packs()

        return self.orders, 0, jsonpickle.encode(self.future_trader_data)

    def hydrogel_packs(self):
        """
        Trading algorithm specifically for hydrogel_packs

        HYDROGEL_PACK is a product that experiences some level of drift, but nothing crazy
        Their true price starts at around 10000, but beyond that it is a mystery
        However, we have determined that there is a market making bot that has consistent order sizes
        We can use that to determine fair price

        Strategy
        Undercut other market makers by 1 unit, offering at just above and below their bid/ask
        Balance market making based on position
        Always take bids/asks that cross the fair price

        Notes
        Appears to be entirely random drift unfortunately
        """

        # Ash Coated Osmium
        HYDROGEL_PACK = "HYDROGEL_PACK"

        orders: List[Order] = []
        bids: Dict[int, int] = self.state.order_depths[HYDROGEL_PACK].buy_orders
        asks: Dict[int, int] = self.state.order_depths[HYDROGEL_PACK].sell_orders

        effective_position: int = self.state.position.get(HYDROGEL_PACK, 0)

        if (
            bids[sorted(bids.keys())[0]] > 10 or
            (bids[sorted(bids.keys())[0]] == 10 and bids[sorted(bids.keys())[1]] >= 20)
        ):
            bid_wall = sorted(bids.keys())[0]
        else:
            bid_wall = sorted(bids.keys())[1]

        if (
            asks[sorted(asks.keys())[-1]] > 10 or
            (asks[sorted(asks.keys())[-1]] == 10 and asks[sorted(asks.keys())[-2]] >= 20)
        ):
            ask_wall = sorted(asks.keys())[0]
        else:
            ask_wall = sorted(asks.keys())[1]

        price_estimate = (ask_wall + bid_wall) // 2

        """
        Taking immediately profitable trades
        """

        for bid in bids.keys():
            if bid > price_estimate:
                orders.append(Order(HYDROGEL_PACK,
                                    bid,
                                    -1 * bids[bid]))
                effective_position += -1 * bids[bid]

        for ask in asks.keys():
            if ask < price_estimate:
                orders.append(Order(HYDROGEL_PACK,
                                    ask,
                                    -1 * asks[ask]))
                effective_position += -1 * asks[ask]

        """
        Finding the best prices to market make at
        """

        best_mm_bid = -1
        best_mm_ask = -1

        for bid in sorted(bids.keys(), reverse=True):
            if bid + 1 < price_estimate:
                best_mm_bid = bid + 1

        for ask in sorted(bids.keys()):
            if ask - 1 > price_estimate:
                best_mm_ask = ask - 1

        """
        Market Making
        """
        bid_number = 0
        ask_number = 0

        if effective_position > 30:
            bid_number = int((80 - effective_position) / 2)
        else:
            bid_number = 40

        if effective_position < -30:
            ask_number = int((-80 - effective_position) / 2)
        else:
            ask_number = -40

        if best_mm_bid != -1:
            orders.append(Order(HYDROGEL_PACK,
                                best_mm_bid,
                                bid_number)
                          )

        if best_mm_ask != -1:
            orders.append(Order(HYDROGEL_PACK,
                                best_mm_ask,
                                ask_number)
                          )

        self.orders[HYDROGEL_PACK] = orders